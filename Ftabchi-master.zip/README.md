<h1><p align="center"> AdvertiserBot 🖕😂 Based on Old Tg
<h2><p align="center">🔅".دانش بدون تکامل اخلاقی خطرناک و نابود کننده است"🔅
<hr>
<h3> <strong>🌐 Installation </strong>
<h6>(Inter line by line in terminal)</h6>
<pre>
<span>cd $HOME</span>
<span>git clone https://github.com/i-Naji/Ftabchi.git</span>
<span>cd Ftabchi</span>
<span>chmod +x launch.sh</span>
<span>chmod +x steady.sh</span>
<span>./launch.sh install</span>
</pre>
<h4> <strong>After installing  the prerequisites,<br>Input your id in bot.lua (line 4),then launch the bot by using of ID (is a number): </strong>
<pre>
<span>./launch.sh ID</span> (#phone and Telegram code)
</pre>
<h6>(Each ID is for one Bot.Don't use a same phone number for your bots)</h6>
<h4> It's Done! Enjoy your bot.
<br><br><br>
#Launch All bots by one Autolaunch cammand :
<pre>
<span>sudo tmux new-session -s Ftabchi "bash launch.sh autolaunch"</span>
</pre>
